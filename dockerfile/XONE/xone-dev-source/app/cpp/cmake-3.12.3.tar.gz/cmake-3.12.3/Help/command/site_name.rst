site_name
---------

Set the given variable to the name of the computer.

::

  site_name(variable)
